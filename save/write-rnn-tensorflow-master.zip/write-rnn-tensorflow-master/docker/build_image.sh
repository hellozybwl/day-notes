docker build --tag write-rnn-tensorflow:1.5.0-py3 .

